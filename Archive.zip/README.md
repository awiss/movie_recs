# CIS 550 Project
run `pip install -r requirements.txt` to install module dependencies

To run server, run `python app.py`
